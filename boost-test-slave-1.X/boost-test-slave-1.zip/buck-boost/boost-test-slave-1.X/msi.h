#include <stdbool.h>
#include <stdint.h>

bool MSI_SendOutputVoltage(uint16_t outputVoltage);
bool MSI_SendInputVoltage(uint16_t inputVoltage);
